
<form action="/admin778899.php/letter/addgroupletter" class="submit_link wz" target="ajax" call="addletter" method="post">
<table cellpadding="0" cellspacing="0" width="450" class="layout">
	<tr>
		<td></td>
		<td>（该操作涉及大量数据，确定后请勿多次点击，以防浏览器假死！）</td>
	</tr>
	<tr>
		<td></td>
		<td>群发站内信内容请尽量简短扼要！</span></td>
	</tr>
	<tr>
		<td>主题：</td>
		<td><label><input type="text" name="title" style="width:400px;"/></label></td>
	</tr>
	<tr>
		<td>内容：</td>
		<td><textarea name="content" style="height:200px; width:400px;"></textarea></td>
	</tr>
	<tr>
		<td><span class="spn9"></span></td>
		<td><span class="spn9"><input type="submit" value="确认发送"></span></td>
	</tr>
</table>
</form>