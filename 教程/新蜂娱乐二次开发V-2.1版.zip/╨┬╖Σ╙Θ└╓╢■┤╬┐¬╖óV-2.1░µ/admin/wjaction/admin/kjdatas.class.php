<?php
class kjdatas extends AdminBase{
	/**
	 * �������
	 */
	public final function tests(){
		$this->display('kjdatas/list.php');
	}
}