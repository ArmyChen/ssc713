<?php
class Admin extends AdminBase{
	public final function index($params=''){
		$this->display('index6215742.php');
	}
	
	public final function login($params=''){
		$this->display('login8421039.php');
	}
	
}